/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package UIPackage;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.swing.SwingConstants;
import java.awt.Insets;
import javax.swing.BorderFactory;
import java.awt.Toolkit;
/**
 *
 * @author Admin
 */
public class LandingPage extends javax.swing.JFrame {

    /**
     * Creates new form LandingPage
     */
    public LandingPage() {
        
        
        initComponents();

        try
        {
            //System.out.println("jpg 2 " + getClass().getResource("/images/01.jpg"));
            BufferedImage sideArtImg = ImageIO.read(getClass().getResource("/images/2561-bearded-dragon-lawler.jpg")); //grab the image file from the resources package
            Image resizedSideArt = sideArtImg.getScaledInstance(sideArtLabel.getWidth(), sideArtLabel.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon sideArtIcon = new ImageIcon(resizedSideArt);  //create an image icon from the image
            
            sideArtLabel.setIcon(sideArtIcon);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        /*
        try
        {
            //System.out.println("jpg 2 " + getClass().getResource("/images/communityIcon_6j0e2cpept361.png"));
            BufferedImage dragonImg = ImageIO.read(getClass().getResource("/images/communityIcon.jpg")); //grab the image file from the resources package
            Image resizedDragon = dragonImg.getScaledInstance(newDragon.getWidth(), newDragon.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon dragonIcon = new ImageIcon(resizedDragon);  //create an image icon from the image
            
            newDragon.setIcon(dragonIcon);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }*/

                try
        {
            //System.out.println("jpg 2 " + getClass().getResource("/images/communityIcon_6j0e2cpept361.png"));
            BufferedImage dragonIm = ImageIO.read(getClass().getResource("/images/noun-bearded-dragon.jpg")); //grab the image file from the resources package
            Image resized = dragonIm.getScaledInstance(dragonIconTester.getWidth(), dragonIconTester.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon dragonIco = new ImageIcon(resized);  //create an image icon from the image
            
            dragonIconTester.setIcon(dragonIco);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
                
                                try
        {
            BufferedImage plusIm = ImageIO.read(getClass().getResource("/images/noun-plus.jpg")); //grab the image file from the resources package
            Image resizedPlus = plusIm.getScaledInstance((jButton2.getWidth() * 1/4), jButton2.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon plusIco = new ImageIcon(resizedPlus);//create an image icon from the image
            
            jButton2.setIcon(plusIco);
                            jButton2.setHorizontalAlignment(SwingConstants.LEFT);
                jButton2.setHorizontalTextPosition(SwingConstants.TRAILING);
                
            //jButton2.setIconTextGap(50);
            //jButton2.setBorder(BorderFactory.createEmptyBorder(4, 4, 2, 20));
            //jButton2.setIcon(plusIco);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
                                
                                
                                
        try
        {
            BufferedImage plusIm = ImageIO.read(getClass().getResource("/images/noun-bearded-dragonr.jpg")); //grab the image file from the resources package
            Image resizedPlus = plusIm.getScaledInstance((jButton3.getWidth() * 1/5), (jButton3.getHeight() * 7/8),Image.SCALE_SMOOTH);
            ImageIcon plusIco = new ImageIcon(resizedPlus);//create an image icon from the image
            
            jButton3.setIcon(plusIco);
                            jButton3.setHorizontalAlignment(SwingConstants.LEFT);
                jButton3.setHorizontalTextPosition(SwingConstants.TRAILING);
            
            //jButton2.setIconTextGap(50);
            //jButton2.setBorder(BorderFactory.createEmptyBorder(4, 4, 2, 20));
            //jButton2.setIcon(plusIco);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
                
            /*    
                try
        {
            //System.out.println("jpg 2 " + getClass().getResource("/images/communityIcon_6j0e2cpept361.png"));
            BufferedImage dragonImg = ImageIO.read(getClass().getResource("/images/noun-bearded-dragon-4604767.jpg")); //grab the image file from the resources package
            Image resizedDragon = dragonImg.getScaledInstance(newIcon.getWidth(), newIcon.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon dragonIcon = new ImageIcon(resizedDragon);  //create an image icon from the image
            
            newIcon.setIcon(dragonIcon);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }  */      
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        choicePanel = new javax.swing.JPanel();
        dragonProfile = new javax.swing.JPanel();
        dragonIconTester = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        sideArtPanel = new javax.swing.JPanel();
        sideArtLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("How To Feed Your Dragon");

        choicePanel.setBackground(new java.awt.Color(196, 79, 0));

        dragonProfile.setBackground(new java.awt.Color(183, 56, 18));

        jButton1.setFont(new java.awt.Font("Britannic Bold", 0, 18)); // NOI18N
        jButton1.setText("Torrin the Terrible");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setFocusPainted(false);

        javax.swing.GroupLayout dragonProfileLayout = new javax.swing.GroupLayout(dragonProfile);
        dragonProfile.setLayout(dragonProfileLayout);
        dragonProfileLayout.setHorizontalGroup(
            dragonProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dragonProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dragonIconTester, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        dragonProfileLayout.setVerticalGroup(
            dragonProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dragonProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dragonProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dragonIconTester, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        label1.setFont(new java.awt.Font("Britannic Bold", 0, 36)); // NOI18N
        label1.setText("HOW");

        label2.setFont(new java.awt.Font("Britannic Bold", 0, 30)); // NOI18N
        label2.setText("Feed Your Dragon");

        label3.setFont(new java.awt.Font("Britannic Bold", 0, 18)); // NOI18N
        label3.setText("to");

        jButton2.setBackground(new java.awt.Color(126, 24, 0));
        jButton2.setFont(new java.awt.Font("Britannic Bold", 0, 18)); // NOI18N
        jButton2.setText("New/Edit Dragon");
        jButton2.setBorderPainted(false);
        jButton2.setFocusPainted(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setIconTextGap(16);

        jButton3.setBackground(new java.awt.Color(126, 24, 0));
        jButton3.setFont(new java.awt.Font("Britannic Bold", 0, 18)); // NOI18N
        jButton3.setText("Torrin");
        jButton3.setBorderPainted(false);
        jButton3.setFocusPainted(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setIconTextGap(16);

        javax.swing.GroupLayout choicePanelLayout = new javax.swing.GroupLayout(choicePanel);
        choicePanel.setLayout(choicePanelLayout);
        choicePanelLayout.setHorizontalGroup(
            choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dragonProfile, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, choicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label2, javax.swing.GroupLayout.DEFAULT_SIZE, 248, Short.MAX_VALUE)
                    .addGroup(choicePanelLayout.createSequentialGroup()
                        .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        choicePanelLayout.setVerticalGroup(
            choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, choicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(choicePanelLayout.createSequentialGroup()
                        .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, choicePanelLayout.createSequentialGroup()
                        .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dragonProfile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(307, 307, 307))
        );

        sideArtLabel.setText("jLabel1");

        javax.swing.GroupLayout sideArtPanelLayout = new javax.swing.GroupLayout(sideArtPanel);
        sideArtPanel.setLayout(sideArtPanelLayout);
        sideArtPanelLayout.setHorizontalGroup(
            sideArtPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, sideArtPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(sideArtLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        sideArtPanelLayout.setVerticalGroup(
            sideArtPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sideArtLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(choicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sideArtPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(choicePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(sideArtPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LandingPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LandingPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LandingPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LandingPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LandingPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel choicePanel;
    private javax.swing.JLabel dragonIconTester;
    private javax.swing.JPanel dragonProfile;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    private javax.swing.JLabel sideArtLabel;
    private javax.swing.JPanel sideArtPanel;
    // End of variables declaration//GEN-END:variables
}

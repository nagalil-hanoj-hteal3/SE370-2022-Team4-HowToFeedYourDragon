/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class Menu {
    //Private List<FoodItem> menuList = new ArrayList<FoodItem>();
    
private FoodItem[] greens = new FoodItem[3];
private FoodItem[] veggies = new FoodItem[2];
private FoodItem[] insects = new FoodItem[2];
private FoodItem fruit;
private FoodItem other;
private boolean otherUsed = false;


public Menu()
{
    //blank constructor holds the default menu loaded?
    //other = ;
}

public FoodItem[] getGreens() {return greens;}
public FoodItem[] getVeggies() {return veggies;}
public FoodItem[] getInsects() {return insects;}
public FoodItem getFruit() {return fruit;}
public FoodItem getOther() {return other;}

public boolean haveOther() {return otherUsed;}

public void setOther(FoodItem o) {other = o; otherUsed = true;}

public void setFruit(FoodItem f) {fruit = f;}

public void setInsects(FoodItem f1, FoodItem f2) {insects[0] = f1; insects[1] = f2;}

public void setVeggies(FoodItem f1, FoodItem f2) {veggies[0] = f1; veggies[1] = f2;}

public void setGreens(FoodItem f1, FoodItem f2, FoodItem f3) {greens[0] = f1; greens[1] = f2; greens[2] = f3;}

//print menu for testing
public void whatsOnTheMenu()
{
    System.out.println("What's on the menu?????");
    System.out.println(greens[0].nameGetter());
    System.out.println(greens[1].nameGetter());
    System.out.println(greens[2].nameGetter());
    System.out.println(veggies[0].nameGetter());
    System.out.println(veggies[1].nameGetter());
    System.out.println(insects[0].nameGetter());
    System.out.println(insects[1].nameGetter());
    System.out.println(fruit.nameGetter());
    
    if(otherUsed == true)
        System.out.println(other.nameGetter());
    
}
 
}

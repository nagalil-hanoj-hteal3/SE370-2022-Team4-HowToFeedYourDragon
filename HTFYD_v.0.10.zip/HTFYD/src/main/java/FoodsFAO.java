
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
 
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class FoodsFAO
{
    
    public void getFoods()
    {
        //take global foods list and populate it from the file
        JSONParser jsonParser = new JSONParser();
        try 
        {
            JSONObject obj = (JSONObject) jsonParser.parse(new FileReader("C:\\Users\\Admin\\Documents\\NetBeansProjects\\FoodsFAOAndMenuTryout\\src\\main\\java\\com\\mycompany\\foodsfaoandmenutryout\\Foods.json"));
            
            System.out.println("Hello World");
            
            DragonMain.foodList.add(obj.get("Greens"));
            DragonMain.foodList.add(obj.get("Vegetables"));
            DragonMain.foodList.add(obj.get("Insects"));
            DragonMain.foodList.add(obj.get("Fruits")); //works
            DragonMain.foodList.add(obj.get("Other"));
            
            //System.out.println(Driver.foodList);
        }
          catch (FileNotFoundException f) {
            f.printStackTrace();
        } catch (IOException i) {
            i.printStackTrace();
        } catch (ParseException p) {
            p.printStackTrace();
        }
    }
    
    //save/modify foodItem
    public void updateFood(String key, String newValue)
    {
        try{
            JSONParser jsonFoodParser = new JSONParser();
            FileReader reader = new FileReader("Foods.json");
            Object obj = jsonFoodParser.parse(reader);
            
            JSONObject toBeUpdated = (JSONObject) obj;
            toBeUpdated.put(key, newValue);
        }
        catch(Exception e)
        {
        System.out.println(e);
        }   
    }
    
/*
    public static void parseFoodObject(JSONObject foodsList) //"getFood()"
    {
        JSONObject foodsObject = (JSONObject) foodsList.get("food"); //make foodList global and this error should be fixed

        String foodName = (String) foodsList.get("foodName");    

        String foodRes = (String) foodsList.get("foodRes");    

        String foodDate = (String) foodsList.get("foodDate");    
    }
    */
}
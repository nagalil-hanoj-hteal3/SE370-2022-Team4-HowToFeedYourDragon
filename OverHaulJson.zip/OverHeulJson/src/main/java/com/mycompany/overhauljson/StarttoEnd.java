/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.overhauljson;

/**
 *@description A small helper class that will help the program know where foods of a type are located in the master list
 * @author Lily Bailey
 */
public class StarttoEnd {
    private final int start;
    private final int end;
    
    StarttoEnd(int s, int e) {start = s; end = e;}
    public int startGetter() {return start;}
    public int endGetter() {return end;}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.overhauljson;
import java.util.*;
/**
 *
 * @author Admin
 */
public class Driver {
//public static FoodItem[] foodList;
    //public static List<FoodItem> foodList = new ArrayList<FoodItem>(); //global foodItem list
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here   
        
        //instantiate foodsFAO
        FoodsFAO fao = new FoodsFAO();
        
        //populate the foodList
        fao.populateFoodsList();
        //fao.saveFoods();
        
        //set the first item to true and print it to see if it works and populates correctly
        fao.setFoodListElementChecked(0, true);
        fao.setFoodListElementChecked(11, true);
        fao.setFoodListElementChecked(10, true);
        fao.setFoodListElementChecked(90, true);
        fao.setFoodListElementChecked(5, true);
        fao.setFoodListElementChecked(70, true);
        fao.setFoodListElementChecked(20, true);
        fao.setFoodListElementChecked(30, true);
        fao.setFoodListElementChecked(40, true);
        fao.setFoodListElementChecked(50, true);
        fao.setFoodListElementChecked(60, true);
        fao.setFoodListElementChecked(80, true);
        fao.saveFoods();

        fao.saveFoods();
        fao.populateFoodsList();
        fao.printFoodsList(); //works!
        

         //works, now I know the fao overwrites the file and in the way I want
        
        MenuBuilder m = new MenuBuilder();
        Menu todaysMenu = new Menu();
        
        todaysMenu = m.buildMenu(fao);
        todaysMenu.whatsOnTheMenu();
    }
    
}

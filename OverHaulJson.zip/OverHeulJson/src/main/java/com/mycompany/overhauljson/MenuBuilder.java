/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.overhauljson;
import java.util.*;

/**
 *
 * @author Admin
 */
public class MenuBuilder {
    
//    private List<FoodItem> menu = new ArrayList<>();
    
    public Menu buildMenu(FoodsFAO fao) //fao passed to function from foodsSelection menu
    {
        FoodItem temp;
        List<FoodItem> checkedGreens = new ArrayList<>();
        List<FoodItem> checkedVeggies = new ArrayList<>();
        List<FoodItem> checkedFruit = new ArrayList<>();
        List<FoodItem> checkedInsects = new ArrayList<>();
        List<FoodItem> checkedOther = new ArrayList<>();
        //FoodsFAO fao = new FoodsFAO();
        
        
        for(int i = 0; i < fao.getFoodListSize(); i++) //get all the checked foods and put them into hceckedFoodsOnly list
        {
            temp = fao.getFoodListElement(i); //get the FoodItem at slot i
            
            if(temp.checkedGetter() == true) //if the checked status of a FoodItem is true,
            {
                //checkedFoodsOnly.add(temp); //add it to the checkedFoodsOnly list

                //add the food item to its respective type list, rule switch              
                switch(temp.typeGetter())
                {
                    case "Greens" -> checkedGreens.add(temp);
                    case "Vegetables" -> checkedVeggies.add(temp);
                    case "Insects" -> checkedInsects.add(temp);
                    case "Fruit" -> checkedFruit.add(temp);
                    case "Other" -> checkedOther.add(temp);
                }
                
            }
        }
        
        //now we have lists of checked greens, veggies, etc
        Menu todaysMenu = new Menu(); 
        
        //start with other category
        //if we have something checked for other foods, pick ONE thing and pass it to the menu object's setter method
        if(!checkedOther.isEmpty()) //if scheckedOther list contains something
        {
            todaysMenu.setOther(returnRandomElement(checkedOther)); //get a random element from the other checked list
        }
        
        //now for fruit
        if(!checkedFruit.isEmpty()) //if any fruit have been checked
        {
            todaysMenu.setFruit(returnRandomElement(checkedFruit)); //get a random one and feed it into the menu
        }
        else
        {
            todaysMenu.setFruit(returnRandomElementFromPortionofList(fao, (fao.getFruitRange()))); //get a random fruit from the master list
        }
        
        //now for insects
        if(!checkedInsects.isEmpty()) //if there is anything checked for insects
        {
            todaysMenu.setInsects(returnRandomElement(checkedInsects), returnRandomElement(checkedInsects)); //picked 2 things at random. can get DUPLICATES
        }
        else //otherwise pick two random things from the master list, can get DUPLICATES
        {
            todaysMenu.setInsects(returnRandomElementFromPortionofList(fao, fao.getInsectsRange()), returnRandomElementFromPortionofList(fao, fao.getInsectsRange()));
        }
        
        //again for veggies
        if(!checkedVeggies.isEmpty()) //if there is anything checked for veggies
        {
            todaysMenu.setVeggies(returnRandomElement(checkedVeggies), returnRandomElement(checkedVeggies)); //picked 2 things at random. can get DUPLICATES
        }
        else //otherwise pick two random things from the master list, can get DUPLICATES
        {
            todaysMenu.setVeggies(returnRandomElementFromPortionofList(fao, fao.getVeggiesRange()), returnRandomElementFromPortionofList(fao, fao.getVeggiesRange()));
        }
        
       //lastly for greens
        if(!checkedGreens.isEmpty()) //if there is anything checked for veggies
        {
            todaysMenu.setGreens(returnRandomElement(checkedGreens), returnRandomElement(checkedGreens), returnRandomElement(checkedGreens)); //picked 3 things at random. can get DUPLICATES
        }
        else //otherwise pick three random things from the master list, can get DUPLICATES
        {
            todaysMenu.setGreens(returnRandomElementFromPortionofList(fao, fao.getGreensRange()), returnRandomElementFromPortionofList(fao, fao.getGreensRange()), returnRandomElementFromPortionofList(fao, fao.getGreensRange()));
        }
        
        return todaysMenu;
    }
    
    
    //helper function returns a random element from a portion of the master list
    public FoodItem returnRandomElementFromPortionofList (FoodsFAO fao, StarttoEnd s)
    {
        Random r = new Random();
        int randominRange =  r.nextInt(s.endGetter() - s.startGetter()) + s.startGetter();
        FoodItem randomElement = fao.getFoodListElement(randominRange);
        return randomElement;
    }
    
    //helper function returns a random element from a list
    public FoodItem returnRandomElement(List<FoodItem> checkedFoodsList)
    {
        Random r = new Random();
        FoodItem randomElement = checkedFoodsList.get(r.nextInt(checkedFoodsList.size()));
        return randomElement;
    }
}


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.json.Json;

import javax.json.JsonObject;
import javax.json.JsonArray;
import javax.json.JsonString;
import javax.json.JsonValue;
import javax.json.stream.JsonParser;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class FoodsFAO
{
    
    public void getFoods(JsonArray foodList)
    {
        //take global foods list and populate it from the ffle
        
        try 
        {
         JsonParser jsonParser = Json.createParser(new FileReader("Foods.json"));
            
            
            foodList.getJsonArray(0);
            foodList.getJsonArray(1);
            foodList.getJsonArray(2);
            foodList.getJsonArray(3); //works
            foodList.getJsonArray(4);
            
            //System.out.println(Driver.foodList);
        }
          catch (FileNotFoundException f) {
            f.printStackTrace();
        } catch (IOException i) {
            i.printStackTrace();
        } 
    }
    
    //save/modify foodItem
    public void updateFood(String key, String newValue)
    {
        try{
            JSONParser jsonFoodParser = new JSONParser();
            FileReader reader = new FileReader("Foods.json");
            Object obj = jsonFoodParser.parse(reader);
            JsonObject toBeUpdated = (JsonObject) obj;
           //toBeUpdated.replace(key, JsonValue.ValueType.STRING.newValue newValue = new newValue(););
        }
        catch(Exception e)
        {
        System.out.println(e);
        }   
    }
    
}
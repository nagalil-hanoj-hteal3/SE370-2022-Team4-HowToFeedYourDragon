import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
 
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
 
public class ProfileFAO
{
    JSONParser jsonProfileParser = new JSONParser();

    try (FileReader reader = new FileReader("Foods.json"))
    {
        Object obj = jsonProfileParser.parse(reader);//read the json file

        JSONArray profileList = (JSONArray) obj;
        System.out.println(profileList);

        profileList.forEach(profile->parseProfileObject((JSONObject) profile));

    } catch (FileNotFoundException p) {
        p.printStackTrace();
    } catch (IOException p) {
        p.printStackTrace();
    } catch (ParseException p) {
        p.printStackTrace();
    }

    private static void parseProfileObject(JSONObject profiles)
    {
        JSONObject profilesObject = (JSONObject) profiles.get("profile");

        String profilesSex = (String) profilesObject.get("Sex");    

        String profilesAge = (String) profilesObject.get("Age");    

        String profilesName = (String) profilesObject.get("Name");    
    }
    
}

import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class WriteProfile extends ProfileFAO
{
    @SuppressWarnings("unchecked")
    {
        //Sex of the pet
        JSONObject SexDet = new JSONObject();
        SexDet.put("Male");
        SexDet.put("Female");

        JSONObject SexObj = new JSONObject();
        SexObj.put("Sex: ", SexDet);

//___________________________________________________

        //Age of the pet
        JSONObject AgeDet = new JSONObject();
        AgeDet.put(" ");

        JSONObject AgeObj = new JSONObject();
        AgeObj.put("Age: ", AgeDet);
        
//___________________________________________________

        //Name of the pet
        JSONObject NameDet = new JSONObject();
        NameDet.put(" ");

        JSONObject NameObj = newJSONObject();
        NameObj.put("Name: ", NameDet);
        
    }
}
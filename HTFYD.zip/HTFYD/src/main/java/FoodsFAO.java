/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class FoodsFAO {
    
    public void populateFoodsList()
    {
        String type;
        String name;
        boolean checked;
        String line;
        
      
        try
        {
            //File foods = new File("Foods.txt"); //get the foods file
            File foods = new File("./src/main/resources/Foods.txt");
            Scanner sc = new Scanner(foods);//we want to use scanner class since it can parse primitive types and strings from our input file  
            
           while(sc.hasNextLine()) //loop stops at the end of the file
           {
            line = sc.nextLine(); //take in a line of input from the file
            String[] input = line.split(","); //make an array of strings split at the commas from the line of file input
            
            type = input[0]; //the first string in the array has food type
            name = input[1]; //food name
            checked = Boolean.parseBoolean(input[2]); //the checkbox status of the foodItem
            
            FoodItem f = new FoodItem(type, name, checked);
            LandingFrame.foodList.add(f);
            
           }
           
        }
        catch(Exception e) //file throws fileNotFound exception so catch it here
        {
            System.out.println(e);
        }
    }
}

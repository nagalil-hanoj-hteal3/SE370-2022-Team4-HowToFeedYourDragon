/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Home
 */
public class StarttoEnd {
    private final int start;
    private final int end;
    
    public StarttoEnd(int s, int e) {start = s; end = e;}
    public int startGetter() {return start;}
    public int endGetter() {return end;}
}

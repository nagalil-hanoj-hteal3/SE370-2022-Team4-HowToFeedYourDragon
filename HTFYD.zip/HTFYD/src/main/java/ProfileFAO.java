import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
 
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
 
public class ProfileFAO
{
    JSONParser jsonProfileParser = new JSONParser();

    
    
    private class getProfile {

        public getProfile() {
            
            
       
    try {
        FileReader reader = new FileReader("Profile.json");
        Object obj = jsonProfileParser.parse(reader);//read the json file

        JSONArray profileList = (JSONArray) obj;
        System.out.println(profileList);

        profileList.forEach(profile->parseProfileObject((JSONObject) profile));

    } catch (FileNotFoundException p) {
        p.printStackTrace();
    } catch (IOException p) {
        p.printStackTrace();
    } catch (ParseException p) {
        p.printStackTrace();
    }
} }
    
    private static void createProfile()
    {
        
    }
    
    
    
    private static void parseProfileObject(JSONObject profiles)
    {
        JSONObject profilesObject = (JSONObject) profiles.get("profile");

        String profilesSex = (String) profiles.get("Sex");    

        String profilesAge = (String) profiles.get("Age");    

        String profilesName = (String) profiles.get("Name");    
    }

    
}
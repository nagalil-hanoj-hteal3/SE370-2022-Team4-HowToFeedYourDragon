/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * small class that will let us populate an array of FoodItems
 */
public class FoodItem {
    private String type;
    private String name;
    private boolean checked;
    
   public FoodItem(String t, String n, boolean c) //constructor for foodItem
   {
       type = t;
       name = n;
       checked = c;
   }
   
   public String typeGetter()
   {
       return type;
   }
   
   public String nameGetter()
   {
       return name;
   }
   
   public boolean checkedGetter()
   {
       return checked;
   }
   
   public void changeCheckedStatus(boolean c)
   {
       checked = c;
   }
   
   public String toPrintFoodItem(FoodItem f) //lets me print an item to check if the list is populating as it should
   {
       return "The food type is " + type + ", its name is " + name + ", and its checked status is " + checked + ".";
   }
}

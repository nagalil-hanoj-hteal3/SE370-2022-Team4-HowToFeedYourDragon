/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class ProfileFAO {

    private String path = "./src/main/resources/";
    private List<FoodItem> savedMenuItems = new ArrayList<>();
    //private final String path = "."

    public void saveProfile(Profile p) {
        String fileName = "";
        fileName = path + p.nameGetter() + ".txt";

        if (profileExists(p)) {
            try {
                //name and create or retrieve the file we will save the profile in
                File fi = new File(fileName);

                //declare scanner to read the file,  the scanner will read lines into line variable
                Scanner sc = new Scanner(fi);
                String line = "";
                List<String> savedFileItems = new ArrayList<>(); //a list will hold the strings read in

                while (sc.hasNextLine()) //read in every foodItem, this won't execute if the file is newly created and empty
                {
                    line = sc.nextLine(); //get the line          
                    savedFileItems.add(line); //put it in the list
                }

                PrintWriter bw = new PrintWriter(fileName); //declare printwriter for the file

                String fileLine = ""; //new string variable holds the new line we want to write to file
                fileLine = fileLine + p.ageGetter() + ",";
                fileLine = fileLine + p.sexGetter() + ","; //construct the line to be written from the profile's attributes
                fileLine = fileLine + p.nameGetter() + "\n";
                bw.write(fileLine); //print the formatted line to file
                //System.out.println(fileLine);

                for (int i = 1; i < savedFileItems.size(); i++) //iterate through the list of saved file lines, ignoring the first line since it holds the old profile data
                {
                    bw.write(savedFileItems.get(i)); //write each line back to the file
                }
                bw.close(); //close printwriter

            } catch (Exception e) //error catching
            {
                System.out.println(e);
            }
        } 
        else {
            try {
                Path pa = Paths.get(path, p.nameGetter() + ".txt");
                Files.createDirectories(pa.getParent());
                DataOutputStream out = new DataOutputStream(Files.newOutputStream(pa, StandardOpenOption.CREATE, StandardOpenOption.WRITE));
                String fileLine = ""; //new string variable holds the new line we want to write to file
                fileLine = fileLine + p.ageGetter() + ",";
                fileLine = fileLine + p.sexGetter() + ","; //construct the line to be written from the profile's attributes
                fileLine = fileLine + p.nameGetter() + "\n";
                out.writeBytes(fileLine);
                out.flush();
                out.close();
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }

    //assume preexisting profile
    public void saveMenu(Menu m, Profile p) {
        try {
            String fileName = "";
            fileName = path + p.nameGetter() + ".txt"; //name and create the file we will save the menu in
            File file = new File(fileName);

            Scanner sc = new Scanner(file);
            String profileLine = "";
            //List<String> savedFileItems = new ArrayList<>();
            if (sc.hasNextLine()) {
                profileLine = sc.nextLine();
            }

            PrintWriter bw = new PrintWriter(fileName);
            bw.write(profileLine + "\n");

            String fileLine = "";
            FoodItem[] greens;
            greens = m.getGreens();
            for (int i = 0; i < 3; i++) {
                fileLine = greens[i].typeGetter() + "," + greens[i].nameGetter() + "," + greens[i].checkedGetter() + "\n";
                bw.write(fileLine);
            }

            fileLine = "";
            FoodItem[] veggies;
            veggies = m.getVeggies();
            for (int i = 0; i < 2; i++) {
                fileLine = veggies[i].typeGetter() + "," + veggies[i].nameGetter() + "," + veggies[i].checkedGetter() + "\n";
                bw.write(fileLine);
            }

            fileLine = "";
            FoodItem[] insects;
            insects = m.getInsects();
            for (int i = 0; i < 2; i++) {
                fileLine = insects[i].typeGetter() + "," + insects[i].nameGetter() + "," + insects[i].checkedGetter() + "\n";
                bw.write(fileLine);
            }

            fileLine = "";
            FoodItem f;
            f = m.getFruit();
            fileLine = f.typeGetter() + "," + f.nameGetter() + "," + f.checkedGetter() + "\n";
            bw.write(fileLine);

            if (m.haveOther()) {
                fileLine = "";
                f = m.getOther();
                fileLine = f.typeGetter() + "," + f.nameGetter() + "," + f.checkedGetter() + "\n";
                bw.write(fileLine);
            }

            bw.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public boolean profileExists(Profile p) {
        String fileName = "";
        fileName = path + p.nameGetter() + ".txt";

        Path path = Paths.get(fileName);
        if (Files.exists(path)) {
            return true;
        } else {
            return false;
        }
    }

    public void deleteProfile(Profile p) //delete the whole file
    {
        //done by EJ
        String fileName = "";
        fileName = path + p.nameGetter() + ".txt";
        File file = new File(fileName);

        file.delete();
    }

    public void deleteMenu(Profile p) {
        try {
            String fileName = "";
            fileName = path + p.nameGetter() + ".txt"; //name and create the file we will save the menu in
            File file = new File(fileName);

            Scanner sc = new Scanner(file);
            String profileLine = "";
            if (sc.hasNextLine()) {
                profileLine = sc.nextLine();
            }

            PrintWriter bw = new PrintWriter(fileName);
            bw.write(profileLine);

            bw.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //this function is called when a profile button is selected.  that way a new menu is not built over the one that should be used
    public boolean profileHasSavedMenu(Profile p) //determines if a profile has a menu saved to it
    {
        boolean bool = false;

        try {
            String fileName = "";
            fileName = path + p.nameGetter() + ".txt"; //name and create the file we will save the profile in
            File fi = new File(fileName);
            Scanner sc = new Scanner(fi);
            if (sc.hasNextLine()) {
                sc.nextLine(); //skip the first line which has the profile info

                if (sc.hasNextLine()) //if there is still another line to be read in, a saved menu exists for the profile
                {
                    //Menu m = retrieveMenu(p);
                    bool = true;
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        return bool;
    }

    //assumes the profile has a retrievable menu or a menu saved at all
    public Menu retrieveMenu(Profile p) {

        Menu m = new Menu();
        try {
            String fileName = "";
            fileName = path + p.nameGetter() + ".txt"; //name and create the file we will save the profile in
            //path = path + fileName;
            File fi = new File(fileName);
            Scanner sc = new Scanner(fi);

            String line = "";
            sc.nextLine(); //skip the first line which has the profile info we wish to overwrite
            String type = "";
            String name = "";
            boolean checked;
            int i = 0;

            
            while (sc.hasNextLine()) //read in every foodItem
            {
                line = sc.nextLine(); //the next line holds the menu info we want to keep
                //Menu m = new Menu(); //m will save the menu which will be erased whenever the profile is edited
                String[] foodItems = line.split(","); //split the line of fooditem info into attribute tokens
                type = foodItems[0]; //the first string in the array has food type
                name = foodItems[1]; //food name
                checked = Boolean.parseBoolean(foodItems[2]); //the checkbox status of the foodItem
                FoodItem f = new FoodItem(type, name, checked); //get the current foodItem           
                savedMenuItems.add(f); //populate list of saved menu items
            }

            
            //ok, so now we have a list populated with all the FoodItems (8-9) on a saved menu.  Now generate fill int the menu from the list
            m.setGreens(savedMenuItems.get(0), savedMenuItems.get(1), savedMenuItems.get(2)); //very important!  menu items are saved from greens-other
            m.setVeggies(savedMenuItems.get(3), savedMenuItems.get(4)); //next two items are veggies
            m.setInsects(savedMenuItems.get(5), savedMenuItems.get(6));
            m.setFruit(savedMenuItems.get(7));

            if (7 >= savedMenuItems.size()) //because other is only used on the menu if the user has checked sometimng in other, it may not be in the menu
            {
                m.setOther(savedMenuItems.get(8)); //here we determine the index 8 exists and so there is an "other" foorItem to incorporate into the menu
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        //now the menu is fully populated, return it
        return m;
    }

    public Profile retrieveProfile(String profileName) //retrieve a profile from file
    {
        Profile p = new Profile("12/26/2009", "john Doe", "male");

        try {
            String fileName = "";
            fileName = path + profileName + ".txt"; //name and create the file we will save the profile in
            //path = path + fileName;
            File fi = new File(fileName);
            Scanner sc = new Scanner(fi);
            String line = "";

            if (sc.hasNextLine()) {
                line = sc.nextLine();
                String[] profileInfo = line.split(",");
                String age = profileInfo[0];
                String sex = profileInfo[1];
                String name = profileInfo[2];

                //Profile p = new Profile(age, name, sex);
                p.ageSetter(age);
                p.nameSetter(name);
                p.sexSetter(sex);

            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return p;
    }
    
    public List<String> retrieveProfileNames()
    {
        //get the names of all text files in resource directory EXCLUDING foods.txt
        List<String> savedProfileNames = new ArrayList<>();
        File folder = new File(path);
        
        //for(int i )
        return savedProfileNames;
    }

}

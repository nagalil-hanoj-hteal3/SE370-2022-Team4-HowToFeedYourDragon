
import java.awt.CardLayout;
import java.awt.Container;
import javax.swing.JButton;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Home
 */
public class NavCard extends LandingFrame {//this is our card class for navigation pane
    
    CardLayout navCard;
    JButton petButton1;
    Container navPane;
    
    
    NavCard() //constructor for navCard
    {
        navPane = getContentPane();
         
    }
    
}

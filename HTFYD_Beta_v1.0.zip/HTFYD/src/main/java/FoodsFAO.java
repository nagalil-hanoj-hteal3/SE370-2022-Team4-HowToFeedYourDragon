
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * FoodsFAO holds the master foods list, the ranges of food types stored in the list, populates the master foods list, . . .
 * @author Lily Bailey
 */
public class FoodsFAO {
    private final StarttoEnd greensRange = new StarttoEnd(0, 25); //hardcoded inclusive limits for each category in the foodList
    private final StarttoEnd veggiesRange = new StarttoEnd(26, 55);
    private final StarttoEnd insectsRange = new StarttoEnd(56, 66);
    private final StarttoEnd fruitRange = new StarttoEnd(67, 88);
    private final StarttoEnd othersRange = new StarttoEnd(89, 97);
    private final List<FoodItem> foodList = new ArrayList<>();
    //FoodsFAO() { }
    
    public void populateFoodsList()
    {
        String type;
        String name;
        boolean checked;
        String line;
        
      
        try
        {
            //File foods = new File("Foods.txt"); //get the foods file
            File foods = new File("./src/main/resources/Foods.txt");
            Scanner sc = new Scanner(foods);//we want to use scanner class since it can parse primitive types and strings from our input file  
            
           while(sc.hasNextLine()) //loop stops at the end of the file
           {
            line = sc.nextLine(); //take in a line of input from the file
            String[] input = line.split(","); //make an array of strings split at the commas from the line of file input
            
            //System.out.println(input.length);
            //for(int i = 0; i < input.length; i++) //used for testing purposes
             //System.out.println(input[i]);
            
            type = input[0]; //the first string in the array has food type
            name = input[1]; //food name
            checked = Boolean.parseBoolean(input[2]); //the checkbox status of the foodItem
            
            //construct a food object from the data retrieved and store it in the global foodList variable
            FoodItem f = new FoodItem(type, name, checked); //get the current foodItem           
            foodList.add(f);
            
            //System.out.println(name);
            //System.out.println(type); //was using this for testing purposes
            //System.out.println(checked);
           }
           
           /*
           for(int i = 0; i < Driver.foodList.size(); i++)
            System.out.println(Driver.foodList.get(i).toPrintFoodItem(Driver.foodList.get(i)));*/
        }
        catch(Exception e) //file throws fileNotFound exception so catch it here
        {
            System.out.println(e);
        }
    }
    
    public void saveFoods() //rewrite the whole file with the master list
    {
        //use printwriter since it allows formatting
        try
        {
            //FileWriter fw = new FileWriter("./src/main/resources/Files/Foods.txt"); //file writer will overwrite existing file
            //BufferedWriter bw = new BufferedWriter(fw); 
            File foods = new File("./src/main/resources/Foods.txt");  foods.delete();
            PrintWriter bw = new PrintWriter("./src/main/resources/Foods.txt");
            String fileLine = "";
            FoodItem f;
            
            for(int i = 0; i < foodList.size(); i++) //go through the whole foodsList and write it to file
            {
                f = foodList.get(i); //get a foodItem
                
                fileLine = fileLine + f.typeGetter() + ",";
                fileLine = fileLine + f.nameGetter() + ",";
                fileLine = fileLine + f.checkedGetter() + "\n"; //recreates the standard format for a line of info in Foods.txt
                
                bw.write(fileLine); //print the formatted line to file
                //System.out.println(fileLine);
                fileLine = ""; //reset string
            }
            
            bw.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
    public void printFoodsList()
    {
        for(int i = 0; i  < foodList.size(); i++)
            System.out.println(foodList.get(i).toPrintFoodItem(foodList.get(i)));
    }
    
    public List<FoodItem> getFoodList()
    {
        return foodList;
    }
    
    public int getFoodListSize() {return foodList.size();}
    
    public String getFoodListElementType(int i) {return foodList.get(i).typeGetter();}
    
    public String getFoodListElementName(int i) {return foodList.get(i).nameGetter();} //this is used to get the name of a food for the labels on the jcheckboxes
    
    public FoodItem getFoodListElement(int i) {return foodList.get(i);}
    
    public boolean getFoodListElementChecked(int i) {return foodList.get(i).checkedGetter();}
    
    public void setFoodListElementChecked(int i, boolean c) {foodList.get(i).changeCheckedStatus(c);}
    
    public StarttoEnd getFruitRange() {return fruitRange;}
    
    public StarttoEnd getInsectsRange() {return insectsRange;}
    
    public StarttoEnd getVeggiesRange() {return veggiesRange;}
    
    public StarttoEnd getGreensRange() {return greensRange;}
    
    public StarttoEnd getOthersRange() {return othersRange;}
}

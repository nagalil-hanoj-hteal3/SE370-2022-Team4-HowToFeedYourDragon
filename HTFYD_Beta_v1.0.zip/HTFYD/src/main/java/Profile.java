/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Admin
 */
public class Profile {
    private String age;
    private String sex;
    private String name;
    
    public Profile(String a, String s, String n)
    {
        age = a;
        sex = s;
        name = n;
    }
    
    public void nameSetter(String n) {name = n;}
    public void ageSetter(String a) {age = a;}
    public void sexSetter(String s) {sex = s;}
    
    public String sexGetter() {return sex;}
    public String ageGetter() {return age;}
    public String nameGetter() {return name;}
    
    //public String nameGetter() {return name;}
    
    public int ageCalculator() //need to finish
    {
        //string date is month/day/year
        
        return 1;
    }
       
    public String stringProfile()
    {
        return "The dragon's name is " + name + ", its age is " + age + " and its sex is " + sex;
    }
    
    public boolean isAdult() //need to finish
    {
        //string date is month/day/year
        String[] date = age.split("/");
        int month = Integer.parseInt(date[0]);
        int year = Integer.parseInt(date[2]);


        int curMonth = 5;
        int curYear = 2022;

        int ageInMonths = (curYear - year) * 24;
        ageInMonths = ageInMonths + month - curMonth;

        if(ageInMonths >= 24)
            return true;
        else
            return false;
    }
    
    
}
